def hello():
	print('hello world')

print('works when imported')
